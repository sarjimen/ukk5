<?php

include 'fungsi.php';

// Panggil fungsi logout
logout();
